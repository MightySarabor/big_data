package de.hstr.bigdata.secondarysort;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JoinMapper extends Mapper<LongWritable, Text, UserAndSource, Text> {
    private static final Logger LOG = LoggerFactory.getLogger(JoinMapper.class);
    
    private int source;

    @Override
    protected void setup(Context context)
            throws IOException, InterruptedException {
       
        String filename = ((FileSplit) context.getInputSplit()).getPath().getName();
        source = context.getConfiguration().getInt(filename, -1);
        if (source < 0) {
            throw new IllegalStateException(String.format("Input split %s not found in config", filename));
        }
    }

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String line = value.toString();
        String keyStr = line.split("\t")[0];
        String lineRest = line.substring(line.indexOf("\t") + 1);
        
        context.write(new UserAndSource(keyStr, source), new Text(lineRest));
        LOG.info("{} {} - {}", keyStr, source, lineRest);
    }
}
