package de.hstr.bigdata.secondarysort;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.BasicConfigurator;

/**
 * Beispiel für Secondary Sort und zusammengesetzte Schlüssel in MapReduce.
 * 
 * In diesem Beispiel wird ein Join anhand einer Schlüsselspalte zwischen zwei
 * Eingaben berechnet. Es werden also jeweils die zusammenpassenden Einträge
 * aus beiden Eingaben in einer Zeile ausgegeben.
 * 
 * Varianten hiervon würden analog funktionieren, aber bräuchten etwas mehr Aufwand:
 * 
 * <ul>
 *   <li>mehr als zwei Datenquellen</li>
 *   <li>Join über Nicht-Schlüsselspalten, dabei müsste dann ein Kreuzprodukt aus
 *       allen zusammenpassenden Schlüsseln beider Eingaben berechnet werden.</li>
 *   <li>Left/Right/Full Outer Join, also auch diejenigen Zeilen aufzählen, zu denen
 *       kein passendes Gegenstück in der anderen Eingabe gefunden wird.</li>
 * </ul>
 * 
 * Als Beispiel nehmen wir an, wir hätten einen Datensatz mit den Adressen unserer
 * Kunden und einen zweiten mit den Zahlungsdaten und wollten diese über die Kundennamen
 * verbinden.
 * 
 * @author schmi
 *
 */
public class JoinDriver extends Configured implements Tool {

    public static void main(String[] args) throws Exception {
        BasicConfigurator.configure();
        ToolRunner.run(new JoinDriver(), args);
    }
    
    @Override
    public int run(String[] args) throws Exception {
        Job job = Job.getInstance(getConf(), "join");
        
        job.setJarByClass(JoinDriver.class);
        
        job.setMapperClass(JoinMapper.class);
        job.setReducerClass(JoinReducer.class);
        job.setNumReduceTasks(5);
        
        // KeyAndSource ist der zusammengesetzte Schlüssel. Er besteht aus dem
        // Schlüssel (hier: Benutzername) und einem Integer, das die Nummer
        // der Datenquelle (hier 0 für "adressen.txt" oder 1 für "bestellungen.txt") anzeigt.
        job.setMapOutputKeyClass(UserAndSource.class);
        job.setMapOutputValueClass(Text.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        
        // Gruppiere nur nach dem Benutzernamen; dadurch kommen die 
        // zusammengesetzten Schlüssel (meier, 0) und (meier, 1)
        // in eine Gruppe
        job.setGroupingComparatorClass(GroupByUser.class);
        
        // Partitioniere nur nach dem Benutzernamen, s.o.; mehrere Benutzer
        // werden so auf dem gleichen Reducer landen, aber innerhalb dessen
        // nicht in der gleichen Gruppe.
        job.setPartitionerClass(PartitionByUser.class);
        
        // Sortiere die Daten nach dem Benutzer und dann nach der Quelle; 
        // das ist notwendig, damit die Adresse und die Zahlungsdaten 
        // in der Ausgabe in einer definierten Reihenfolge erscheinen.
        job.setSortComparatorClass(SortByUserAndSource.class);
        
        // Nummeriere die beiden Eingaben, damit diese im Mapper
        // unterschieden werden können. Sonst weiß der Mapper nicht,
        // welche Eingabe er gerade bearbeitet.
        FileInputFormat.addInputPath(job, new Path("src/main/resources/adressen.txt"));
        job.getConfiguration().setInt("adressen.txt", 0);
        FileInputFormat.addInputPath(job, new Path("src/main/resources/zahlung.txt"));
        job.getConfiguration().setInt("zahlung.txt", 1);
        
        // Vorsicht, das Ausgabeverzeichnis rekursiv löschen ist normalerweise nur dann
        // eine gute Idee, wenn man genau weiß, dass man da keinen Schaden anrichtet.
        FileSystem.getLocal(getConf()).delete(new Path("output"), true);
        
        FileOutputFormat.setOutputPath(job, new Path("output"));
        
        return job.waitForCompletion(true) ? 0 : 1;
    }
}
