package de.hstr.bigdata.secondarysort;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ComparisonChain;

/**
 * Sortiert die zusammengesetzten Schlüssel erst nach Benutzername und dann 
 * nach Nummer des Quelle, damit die Daten im Reducer in einer definierten Reihenfolge
 * erscheinen, d.h. in jeder Ausgabezeile steht erst die Adresse, dann die Zahlungsdaten. 
 * 
 * @author schmi
 */
public class SortByUserAndSource extends WritableComparator {
    private static final Logger LOG = LoggerFactory.getLogger(SortByUserAndSource.class);
    
    public SortByUserAndSource() {
        // ... true ist notwendig, damit die vereinfachte compare-Methode unten funktioniert;
        // anderenfalls müssten wir uns selbst mit byte[]-Puffern rumschlagen.
        super(UserAndSource.class, null, true);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public int compare(WritableComparable w1, WritableComparable w2) {
        UserAndSource k1 = (UserAndSource) w1;
        UserAndSource k2 = (UserAndSource) w2;
        
        /* ComparisonChain aus Google Guava erleichtert das Sortieren nach
         * mehreren Kriterien. Sonst müsste man erst den Key vergleichen, 
         * falls das 0 ergäbe, müsste man den Value vergleichen usw.
         * ComparisonChain spart uns diese Fallunterscheidung.
         */
        int result = ComparisonChain.start()
                        .compare(k1.getUser(), k2.getUser())
                        .compare(k1.getSource(), k2.getSource())
                        .result();
        
        // Logging an so einer Stelle nur zu Debugging-Zwecken, weil diese Methoden
        // sehr oft in inneren Schleifen aufgerufen werden!
        LOG.info("SortBySource.compare({}, {}) = {}", k1, k2, result);
        
        return result;
    }
    
}
