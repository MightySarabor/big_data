package de.hstr.bigdata.secondarysort;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Partitioniere die Daten anhand der Benutzernamens, damit alle Einträge
 * eines Benutzers auf dem selben Reducer landen.
 * 
 * @author schmi
 */
public class PartitionByUser extends Partitioner<UserAndSource, Text> {
    private static final Logger LOG = LoggerFactory.getLogger(PartitionByUser.class);
    @Override
    public int getPartition(UserAndSource key, Text value, int numPartitions) {
        /* Achtung, Falle: eigentlich möchte man hier den Betrag des Hash-Codes nehmen,
         * also Math.abs(key.getUser().hashCode()). Die Methode abs() hat aber einen
         * blinden Fleck, nämlich abs(Integer.MIN_VALUE) == Integer.MIN_VALUE, und das 
         * ist negativ! Das liegt daran, dass es in Integer eine negative Zahl mehr 
         * gibt als positive Zahlen (die 0 kostet uns eine positive Zahl). Deshalb wird
         * das hier mit einer Bit-Operation gemacht. Integer.MIN_VALUE wird dann auf 0
         * abgebildet, aber das ist für diesen Zweck ok, es geht ja nur um eine Zuordnung
         * von Keys auf Partitionen.
         */
        int partition = (key.getUser().hashCode() & Integer.MAX_VALUE) % numPartitions;  
        
        // Logging an so einer Stelle nur zu Debugging-Zwecken, weil diese Methoden
        // sehr oft in inneren Schleifen aufgerufen werden!
        LOG.info("getPartition({}) = {}", partition);
        return partition;
    }
}
