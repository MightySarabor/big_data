package de.hstr.bigdata.secondarysort;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Reducer für einen vereinfachten Reduce Side Join:
 * 
 * <ul>
 * <li>Wir erwarten genau zwei Eingaben 0 und 1 (siehe Vergleich "... == 2" im Code).</li>
 * <li>Wir erwarten genau zwei Einträge für zusammenpassende Zeilen, nämlich (key, 0) und (key, 1).
 *     Wollte man über Spalten joinen, die nicht Schlüssel sind, müsste man Kreuzprodukte aufzählen,
 *     z. B. 6 Zeilen insgesamt, wenn es drei Einträge in Quelle 0 und zwei Einträge in Quelle 1
 *     zu einem Wert gibt.</li> 
 * </ul>
 * 
 * @author schmi
 *
 */
public class JoinReducer extends Reducer<UserAndSource, Text, Text, Text> {
    private static final Logger LOG = LoggerFactory.getLogger(JoinReducer.class);
    
    @Override
    protected void reduce(UserAndSource key, Iterable<Text> lines, Context context) throws IOException, InterruptedException {
        StringBuffer outputLine = new StringBuffer();
        LOG.info("{} - {}", key, key.getUser());
        int count = 0;
        for (Text line: lines) {
            outputLine.append("\t");
            outputLine.append(line.toString());
            LOG.info("\t{}", line);
            count++;
        }
        // Nur wenn genau zwei Eingaben vorliegen, jeweils eine aus Quelle 0 und 1, dann gebe
        // die Ausgabezeile aus.
        if (count == 2) {
            context.write(new Text(key.getUser()), new Text(outputLine.toString()));
        }
    }
}
