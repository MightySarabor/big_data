package de.hstr.bigdata.secondarysort;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Gruppiert die Tupel der Form (meier, 0), (mueller, 1) usw. nur
 * nach dem Benutzernamen, so dass (meier, 0) und (meier, 1) in einer
 * Gruppe landen.
 * 
 * @author schmi
 */
public class GroupByUser extends WritableComparator {
    private static final Logger LOG = LoggerFactory.getLogger(GroupByUser.class);
    
    public GroupByUser() {
        // ... true ist notwendig, damit die vereinfachte compare-Methode unten funktioniert;
        // anderenfalls müssten wir uns selbst mit byte[]-Puffern rumschlagen.
        super(UserAndSource.class, null, true);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public int compare(WritableComparable w1, WritableComparable w2) {
        UserAndSource k1 = (UserAndSource) w1;
        UserAndSource k2 = (UserAndSource) w2;
        
        // Vergleiche nur anhand des Schlüssels, d.h. des Benutzernamens.
        int result = k1.getUser().compareTo(k2.getUser());
        
        // Logging an so einer Stelle nur zu Debugging-Zwecken, weil diese Methoden
        // sehr oft in inneren Schleifen aufgerufen werden!
        LOG.info("GroupByKey.compare({}, {}) = {}", w1, w2, result);
        return result;
    }
}
