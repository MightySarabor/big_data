package de.hstr.bigdata.secondarysort;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableUtils;

import com.google.common.collect.ComparisonChain;

/**
 * Zusammengesetzter Schlüssel bestehend aus einem Usernamen ("meier")
 * und der Nummer der Datenquelle aus {0, 1}.
 * 
 * @author schmi
 *
 */
public class UserAndSource implements WritableComparable<UserAndSource> {
    private String user;
    private int source;
    
    public UserAndSource() {
    }
    
    public UserAndSource(String user, int source) {
        super();
        this.user = user;
        this.source = source;
    }

    public String getUser() {
        return user;
    }

    public int getSource() {
        return source;
    }

    /**
     * Schreibe die Felder dieses Writables in den Datenstrom out. Wir können
     * hier die Codierung in Bytes selbst übernehmen, oder uns auf Hilfsmethoden
     * aus Writable und WritableUtils verlassen.
     */
    @Override
    public void write(DataOutput out) throws IOException {
        // Einen String schreiben ist unangenehm: erst wird die Länge geschrieben,
        // dann die Bytes in einem bestimmten Encoding (UTF-8). WritableUtils macht
        // das für uns.
        WritableUtils.writeString(out, user);
        
        // writeVInt schreibt eine Integer in einem Encoding variabler Länge: für 
        // kleine Zahlen wird nur ein Byte geschrieben, für mittelgroße zwei usw.
        // Da wir nur 0 und 1 schreiben wollen, ist das viel effizienter als jedes Mal
        // vier Bytes zu schreiben.
        WritableUtils.writeVInt(out, source);
    }

    /**
     * Liest die Felder dieses Writable aus dem Datenstrom in. Muss die Inverse
     * zu write(DataOutput) sein; ein read() auf der Ausgabe von write() muss
     * also wieder das gleiche Objekt ergeben (im Sinne von equals()).
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        // Das ist die Inverse zu write. Beachte die richtige Reihenfolge:
        // erst user, dann source, und in der gleichen Kodierung!
        user = WritableUtils.readString(in);
        source = WritableUtils.readVInt(in);
    }

    /**
     * Brauchen wir strenggenommen in diesem Beispiel nicht, da wir die ganzen 
     * Comparators selbst schreiben, muss ich aber implementieren für das 
     * WritableComparable-Interface, damit ich den vereinfachten WritableComparator 
     * verwenden kann. 
     */
    @Override
    public int compareTo(UserAndSource other) {
        return ComparisonChain.start()
                .compare(user, other.getUser())
                .compare(source, other.getSource())
                .result();
    }

    @Override
    public String toString() {
        return "[" + user + ", " + source + "]";
    }

    /** Die Methoden hashCode() und equals() brauchen wir strenggenommen für dieses
     * Beispiel auch nicht. Im Allgemeinen muss man aber sicherstellen, dass equals() mit hashCode()
     * und compareTo() konsistent ist, sonst passieren komische Dinge, z. B. dass man ein 
     * Objekt in ein HashSet steckt und es dann nicht mehr wiederfindet.
     */
    @Override
    public int hashCode() {
        // Wichtig: verwende die gleichen Felder wie unten in equals
        return Objects.hash(source, user);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserAndSource other = (UserAndSource) obj;
        // Objects.equals kann korrekt mit null umgehen!
        return Objects.equals(source, other.source) && Objects.equals(user, other.user);
    }
    
    

}
