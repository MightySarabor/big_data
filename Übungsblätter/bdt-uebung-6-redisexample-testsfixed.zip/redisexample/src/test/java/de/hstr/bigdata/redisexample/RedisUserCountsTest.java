package de.hstr.bigdata.redisexample;

import static de.hstr.bigdata.redisexample.RedisCredentials.host;
import static de.hstr.bigdata.redisexample.RedisCredentials.password;
import static de.hstr.bigdata.redisexample.RedisCredentials.port;
import static de.hstr.bigdata.redisexample.RedisCredentials.username;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.Jedis;

public class RedisUserCountsTest {
    private UserCounts redisUserCounts;

    @Before
    public void setUp() {
        redisUserCounts = new RedisUserCounts(host(), port(), username(), password());
    }
    
    @After
    public void tearDown() throws Exception {
        Jedis jedis = new Jedis(host(), port());
        jedis.auth(username(), password());
        for (int i = 0; i < 100; i++) {
            jedis.del(username() + ":user" + i);
        }
        jedis.close();
        redisUserCounts.close();
    }
    
    @Test
    public void testCountOne() {
        redisUserCounts.countAccess("user1", "sport");
        
        assertThat(redisUserCounts.getCount("user1", "sport"), is(1));
        assertThat(redisUserCounts.getCount("user2", "sport"), is(0));
    }
    
    @Test
    public void testCountMany() {
        redisUserCounts.countAccess("user1", "page1");
        redisUserCounts.countAccess("user1", "page2");
        redisUserCounts.countAccess("user1", "page2");
        redisUserCounts.countAccess("user2", "page1");
        redisUserCounts.countAccess("user2", "page1");
        redisUserCounts.countAccess("user2", "page2");
        redisUserCounts.countAccess("user2", "page2");
        redisUserCounts.countAccess("user2", "page3");
        redisUserCounts.countAccess("user2", "page3");
        redisUserCounts.countAccess("user2", "page3");
        redisUserCounts.countAccess("user2", "page3");
        redisUserCounts.countAccess("user3", "page1");
        redisUserCounts.countAccess("user3", "page1");
        redisUserCounts.countAccess("user3", "page2");
        redisUserCounts.countAccess("user3", "page2");
        redisUserCounts.countAccess("user3", "page2");
        redisUserCounts.countAccess("user3", "page2");
        redisUserCounts.countAccess("user3", "page3");
        redisUserCounts.countAccess("user3", "page3");
        redisUserCounts.countAccess("user3", "page3");
        
        assertThat(redisUserCounts.getCount("user1", "page1"), is(1));
        assertThat(redisUserCounts.getCount("user1", "page2"), is(2));
        assertThat(redisUserCounts.getCount("user1", "page3"), is(0));
        
        assertThat(redisUserCounts.getCount("user2", "page1"), is(2));
        assertThat(redisUserCounts.getCount("user2", "page2"), is(2));
        assertThat(redisUserCounts.getCount("user2", "page3"), is(4));
        
        assertThat(redisUserCounts.getCount("user3", "page1"), is(2));
        assertThat(redisUserCounts.getCount("user3", "page2"), is(4));
        assertThat(redisUserCounts.getCount("user3", "page3"), is(3));
    }
}
