from redis import StrictRedis

host = "infbdt03.fh-trier.de"
port = "12345"
password = "r3d15-pw-changeme"

redis = StrictRedis(host, port, password = password)

redis.set("foo", "bar")
print(redis.get("foo"))

redis.shutdown()
