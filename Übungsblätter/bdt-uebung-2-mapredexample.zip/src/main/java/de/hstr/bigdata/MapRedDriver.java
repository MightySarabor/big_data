package de.hstr.bigdata;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.BasicConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Treiberklasse für eine typische MapReduce-Applikation.
 * 
 * Baut ein Job-Objekt, konfiguriert dieses und wartet dann
 * auf das Ende des MapReduce-Jobs.
 * 
 * @author schmi
 */
public class MapRedDriver extends Configured implements Tool {
    private static final Logger LOG = LoggerFactory.getLogger(MapRedDriver.class);
    
    public static void main(String[] args) throws Exception {
        BasicConfigurator.configure();
        ToolRunner.run(new MapRedDriver(), args);
    }

    public int run(String[] args) throws Exception {
    	if (args.length != 2) {
    		System.err.println("Aufruf: MapRedDriver <input dir> <output dir>");
    		return -1;
    	}
    	
        Job job = Job.getInstance(getConf());
        job.setJarByClass(MapRedDriver.class);

        // Womöglich müssen die vier Typparameter angepasst werden!
        // (Map|)Output(Key|Value)Class 
        
        job.setMapperClass(MyMapper.class);
        job.setMapOutputKeyClass(LongWritable.class);
        job.setMapOutputValueClass(LongWritable.class);

        job.setReducerClass(MyReducer.class);
        job.setOutputKeyClass(LongWritable.class);
        job.setOutputValueClass(LongWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        // Konfiguration mitgeben:
        //   job.getConfiguration().set("irgendwas", "irgendein Wert");

        LOG.info("Job starten");
        boolean success = job.waitForCompletion(true);
        LOG.info("Job beendet: success = {}", success);
        return success ? 0 : -1;
    }
}
