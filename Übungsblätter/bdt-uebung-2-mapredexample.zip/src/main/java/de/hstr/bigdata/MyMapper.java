package de.hstr.bigdata;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * Mapper-Klasse. Womöglich müssen die vier Typparameter angepasst werden! 
 * (Input-Key, Input-Value, Output-Key, Output-Value) 
 */
public class MyMapper extends Mapper<LongWritable, Text, LongWritable, Text> {
	@Override
	protected void setup(Mapper<LongWritable, Text, LongWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// Setup (einmal pro Mapper ausgeführt!) hierher
	}
	
	@Override
	protected void map(LongWritable key, Text value,
			Mapper<LongWritable, Text, LongWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// Mapper-Logik hierher
	}
}
