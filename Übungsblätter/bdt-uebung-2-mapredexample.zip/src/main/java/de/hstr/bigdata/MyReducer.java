package de.hstr.bigdata;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * Reducer-Klasse. Womöglich müssen die vier Typparameter angepasst werden! 
 * (Input-Key, Input-Value, Output-Key, Output-Value) 
 */
public class MyReducer extends Reducer<LongWritable, Text, LongWritable, Text> {

	@Override
	protected void setup(Reducer<LongWritable, Text, LongWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// Setup (einmal pro Reducer ausgeführt!) hierher
	}

	@Override
	protected void reduce(LongWritable key, Iterable<Text> values,
			Reducer<LongWritable, Text, LongWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// Reducer-Logik hierher
	}
	
}
