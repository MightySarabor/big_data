from pyspark.context import SparkContext

sc = SparkContext()

words = sc.textFile("/data/shakespeare") \
          .flatMap(lambda line: line.split(" ")) \
          .map(lambda word: (word, 1)) \
          .reduceByKey(lambda a, b: a + b) \
          .collect()

sc.stop()

print "-------------------------"
for (k, v) in words:
    print k, v
print "-------------------------"
