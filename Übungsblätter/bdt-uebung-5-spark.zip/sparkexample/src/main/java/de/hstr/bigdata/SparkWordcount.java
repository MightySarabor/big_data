package de.hstr.bigdata;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.google.common.base.Splitter;

import scala.Tuple2;

/**
 * Dies ist das Gleiche wie SparkWordCountFluent, nur mit Zwischenergebnissen, so dass 
 * man die Datentypen besser erkennt.
 */
public class SparkWordcount {
    private static final Logger LOG = Logger.getLogger(SparkWordcount.class);
    
    public static void main(String[] args) throws InterruptedException, IOException {
        if (args.length != 1) {
            System.err.println("Aufruf: spark-submit [Optionen] <job.jar> <pfad>");
            System.exit(1);
        }
        
        SparkConf conf = new SparkConf().setAppName("wordcount");
        JavaSparkContext ctx = new JavaSparkContext(conf);

        // Textfile(s) einlesen - args[0] kann auch ein Verzeichnis sein
        JavaRDD<String> textFile = ctx.textFile(args[0], 10);
        
        // Zeilenweise an den Leerzeichen aufteilen
        JavaRDD<String> flatMap = textFile.flatMap(line -> Splitter.on(" ").split(line).iterator());
        
        // Aus jedem Wort w ein Tupel (w, 1) machen
        JavaPairRDD<String, Integer> mapToPair = flatMap.mapToPair(w -> new Tuple2<>(w, 1));
        
        // Gruppieren nach Key und die Einsen aufaddieren.
        JavaPairRDD<String, Integer> counts = mapToPair.reduceByKey((a, b) -> a + b);
        
        // Resultate in eine Java-Datenstruktur einsammeln. HIER wird jetzt gerechnet.
		List<Tuple2<String, Integer>> collect = counts.collect();
		
		// Alternativ: collectAsMap, dann kommen keine Tupel, sondern eine Map
		// heraus (Vorsicht dabei, wenn die Keys nicht eindeutig sind!).
		// Map<String, Integer> collectAsMap = counts.collectAsMap();
        
        // Tuple2 ist ein Paar von Werten. Die beiden Werte sind in den
        // Feldern _1 und _2 gespeichert. In diesem Fall ist _1 das Wort
        // und _2 ist die Anzahl der Vorkommen.
        for (Tuple2<String, Integer> tuple2 : collect) {
            LOG.info(tuple2._1 + ": " + tuple2._2);
        }
        
        ctx.close();
    }
}
