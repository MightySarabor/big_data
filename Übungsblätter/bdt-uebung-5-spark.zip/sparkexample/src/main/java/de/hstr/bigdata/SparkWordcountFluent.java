package de.hstr.bigdata;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;

import com.google.common.base.Splitter;

import scala.Tuple2;

/**
 * Dies ist das Gleiche wie SparkWordCount, aber im "fluent interfaces"-Stil,
 * also so etwas wie rdd.op1().op2().op3().result().
 */
public class SparkWordcountFluent {
    private static final Logger LOG = Logger.getLogger(SparkWordcountFluent.class);
    
    public static void main(String[] args) throws InterruptedException, IOException {
        if (args.length != 1) {
            System.err.println("Aufruf: spark-submit [Optionen] <job.jar> <pfad>");
            System.exit(1);
        }
        
        SparkConf conf = new SparkConf().setAppName("wordcount");
        JavaSparkContext ctx = new JavaSparkContext(conf);

        List<Tuple2<String, Integer>> results = ctx.textFile(args[0], 10)
                .flatMap(line -> Splitter.on(" ").split(line).iterator())
                .mapToPair(w -> new Tuple2<>(w, 1))
                .reduceByKey((a, b) -> a + b)                
                .collect();
        
        // Tuple2 ist ein Paar von Werten. Die beiden Werte sind in den
        // Feldern _1 und _2 gespeichert. In diesem Fall ist _1 das Wort
        // und _2 ist die Anzahl der Vorkommen.
		for (Tuple2<String, Integer> tuple2 : results) {
            LOG.info(tuple2._1 + ": " + tuple2._2);
        }
        
        ctx.close();
    }
   
}
