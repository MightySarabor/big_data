// Ausführen in der Spark-Shell:
//   spark-shell --master yarn -i spark-wordcount.scala

val words = (sc.textFile("/data/shakespeare") 
          .flatMap(line => line.split(" ")) 
          .map(word => (word, 1))
          .reduceByKey(_ + _)
          .collect())

// Hier ein sc.stop(), damit das Logging aufhört und wir unser Ergebnis besser sehen
sc.stop()

println("-------------------------")
words.foreach { println }
println("-------------------------")
