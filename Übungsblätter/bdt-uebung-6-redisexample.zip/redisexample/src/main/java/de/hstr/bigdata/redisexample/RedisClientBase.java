package de.hstr.bigdata.redisexample;

import redis.clients.jedis.Jedis;

public class RedisClientBase implements AutoCloseable {

    private Jedis jedis;
    
    public RedisClientBase (String host, int port, String user, String password) {
        jedis = new Jedis(host, port);
        jedis.auth(user, password);
    }

    @Override
    public void close() throws Exception {
        jedis.close();
    }

    protected Jedis getJedis() {
        return jedis;
    }
}
