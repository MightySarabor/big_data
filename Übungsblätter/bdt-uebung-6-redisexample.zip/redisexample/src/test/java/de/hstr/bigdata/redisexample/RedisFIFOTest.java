package de.hstr.bigdata.redisexample;

import static de.hstr.bigdata.redisexample.RedisCredentials.host;
import static de.hstr.bigdata.redisexample.RedisCredentials.password;
import static de.hstr.bigdata.redisexample.RedisCredentials.port;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.Jedis;

public class RedisFIFOTest {
    private Jedis jedis;

    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    @Test
    public void testEmpty() throws ClassNotFoundException, IOException {
    }
    
    @Test
    public void testFIFO() throws ClassNotFoundException, IOException {
    }
}
