package de.hstr.bigdata.redisexample;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.Jedis;

public class RedisUserCountsTest {
    private Jedis jedis;

    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() throws Exception {
    }
    
    @Test
    public void testCountOne() {
    }
    
    @Test
    public void testCountMany() {
    }
}
