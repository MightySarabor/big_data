package de.hstr.bigdata.invertedindex;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class IndexReducer extends Reducer<Text, Text, Text, Text> {

    @Override
    protected void setup(Reducer<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
        super.setup(context);
        // Setup-Code hierher
    }

    @Override
    protected void reduce(Text word, Iterable<Text> documentNames, Reducer<Text, Text, Text, Text>.Context context)
            throws IOException, InterruptedException {
    	// Invertierten Index einsammeln und ausgeben
    }
}
