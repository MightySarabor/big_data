package de.hstr.bigdata.invertedindex;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;

public class IndexMapper extends Mapper<LongWritable, Text, Text, Text> {

    @Override
    protected void setup(Mapper<LongWritable, Text, Text, Text>.Context context)
            throws IOException, InterruptedException {
        super.setup(context);
        // Setup-Code, z. B. Stopwords lesen, hierher.
    }

	@Override
    protected void map(LongWritable fileOffset, Text line, Mapper<LongWritable, Text, Text, Text>.Context context)
            throws IOException, InterruptedException {   
		// Mapper-Code hierher
    }

	/**
	 * @param resourceName Dateiname einer Ressource aus /src/main/resources
	 * @return der Inhalt als einzelne Zeilen
	 * @throws IOException
	 */
    private Set<String> readStopwords(String resourceName) throws IOException {
        return new HashSet<>(Resources.readLines(Resources.getResource(resourceName), Charsets.UTF_8));
    }

    /**
     * @param context Hadoop-Kontext
     * @return der Dateiname der aktuellen Eingabe
     */
	private Text inputFileName(Mapper<LongWritable, Text, Text, Text>.Context context) {
		return new Text(((FileSplit) context.getInputSplit()).getPath().getName());
	}

}
