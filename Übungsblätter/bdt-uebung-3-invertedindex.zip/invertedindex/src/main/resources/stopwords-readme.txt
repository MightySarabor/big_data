Stopwords entnommen aus diesem Projekt:

https://github.com/stopwords-iso/stopwords-en